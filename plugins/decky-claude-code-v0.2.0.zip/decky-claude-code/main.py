import asyncio
import os
import shlex

import decky

from claude_deck.session import ClaudeSession, claude_version, find_claude, user_env
from claude_deck.settings import Settings
from claude_deck import steam, troubleshoot, voice

HOME = decky.DECKY_USER_HOME
USER = decky.DECKY_USER


class Plugin:
    settings: Settings
    session: ClaudeSession
    recorder: voice.Recorder
    exit_code = None
    _version_cache = {}

    # ---- lifecycle --------------------------------------------------------

    async def _main(self):
        Plugin.settings = Settings(decky.DECKY_PLUGIN_SETTINGS_DIR)
        Plugin.session = ClaudeSession(Plugin._emit_output, Plugin._emit_exit, decky.logger)
        Plugin.recorder = voice.Recorder(decky.logger)
        decky.logger.info("Claude Code for Deck ready")

    async def _unload(self):
        await Plugin.recorder.cancel()
        await Plugin.session.stop()

    async def _uninstall(self):
        pass

    @staticmethod
    async def _emit_output(chunk: str):
        await decky.emit("cc_output", chunk)

    @staticmethod
    async def _emit_exit(code: int):
        Plugin.exit_code = code
        await decky.emit("cc_exit", code)

    @staticmethod
    def _env() -> dict:
        return user_env(HOME, USER)

    @staticmethod
    def _cwd() -> str:
        cwd = os.path.expanduser(Plugin.settings.get("cwd") or HOME)
        return cwd if os.path.isdir(cwd) else HOME

    # ---- state ------------------------------------------------------------

    async def get_state(self) -> dict:
        binary = find_claude(HOME, Plugin.settings.get("claude_path"))
        version = None
        if binary:
            # `claude --version` is slow to start, so ask once per binary.
            if binary not in Plugin._version_cache:
                Plugin._version_cache[binary] = await asyncio.get_running_loop().run_in_executor(
                    None, claude_version, binary, Plugin._env()
                )
            version = Plugin._version_cache[binary]
        session = Plugin.session
        return {
            "home": HOME,
            "claude_path": binary,
            "claude_version": version,
            "running": session.running,
            "session_cwd": session.cwd,
            "session_mode": session.mode,
            "exit_code": Plugin.exit_code,
            "cwd": Plugin._cwd(),
            "recording": Plugin.recorder.recording,
            "claude_voice": voice.claude_voice_status(HOME),
            "settings": Plugin.settings.public(),
        }

    async def set_settings(self, values: dict) -> dict:
        Plugin.settings.update(values)
        if "claude_path" in values:
            Plugin._version_cache.clear()
        return Plugin.settings.public()

    # ---- session ----------------------------------------------------------

    async def start_session(self, mode: str = "new", cwd: str = "") -> dict:
        """Start claude. mode is "new", "continue" (last conversation) or "resume" (picker)."""
        if cwd:
            Plugin.settings.update({"cwd": cwd})
        cwd = Plugin._cwd()
        args = []
        if mode == "continue":
            args.append("--continue")
        elif mode == "resume":
            args.append("--resume")
        res = await Plugin._launch(args, cwd, mode)
        if res["ok"]:
            Plugin.settings.remember_dir(cwd)
        return res

    async def list_issues(self) -> list:
        return troubleshoot.public_issues()

    async def list_games(self) -> list:
        return await asyncio.get_running_loop().run_in_executor(None, steam.list_games, HOME)

    async def start_assist(self, issue_id: str, appid: str = "") -> dict:
        """Start claude on a quick-start problem, already briefed about it."""
        # Stop the old session first: Claude rewrites ~/.claude.json on exit,
        # which would undo the trust entry written below.
        await Plugin.session.stop()
        try:
            cwd, prompt, dirs = await asyncio.get_running_loop().run_in_executor(
                None, troubleshoot.prepare, HOME, issue_id, appid
            )
            troubleshoot.trust_folder(HOME, cwd)
        except (OSError, ValueError) as e:
            decky.logger.exception("Could not prepare %s", issue_id)
            return {"ok": False, "error": f"Preparazione non riuscita: {e}"}
        # The prompt goes first: --add-dir takes every argument after it.
        args = [prompt]
        if dirs:
            args += ["--add-dir"] + dirs
        return await Plugin._launch(args, cwd, "assist")

    @staticmethod
    async def _launch(args: list, cwd: str, mode: str) -> dict:
        binary = find_claude(HOME, Plugin.settings.get("claude_path"))
        if not binary:
            return {"ok": False, "error": "Claude Code non trovato. Installalo dalla modalità Desktop."}
        args = shlex.split(Plugin.settings.get("extra_args") or "") + args

        if Plugin.settings.get("voice_engine") == "claude":
            # The voice button relies on /voice in tap mode; setting it before
            # launch means the session starts with dictation ready.
            try:
                voice.enable_claude_voice(HOME, Plugin.settings.get("language"))
            except (OSError, ValueError) as e:
                decky.logger.warning("Could not enable Claude voice: %s", e)

        Plugin.exit_code = None
        try:
            await Plugin.session.start(binary, args, cwd, Plugin._env(), mode)
        except OSError as e:
            decky.logger.exception("Could not start claude")
            return {"ok": False, "error": f"Avvio non riuscito: {e}"}
        return {"ok": True}

    async def stop_session(self) -> bool:
        await Plugin.session.stop()
        return True

    async def write(self, data: str) -> bool:
        Plugin.session.write(data)
        return Plugin.session.running

    async def resize(self, rows: int, cols: int) -> bool:
        Plugin.session.resize(rows, cols)
        return True

    async def get_scrollback(self) -> str:
        return Plugin.session.scrollback

    # ---- voice ------------------------------------------------------------

    async def enable_claude_voice(self) -> dict:
        try:
            status = voice.enable_claude_voice(HOME, Plugin.settings.get("language"))
        except (OSError, ValueError) as e:
            return {"ok": False, "error": f"Non riesco a modificare ~/.claude/settings.json: {e}"}
        return {"ok": True, "status": status}

    async def voice_start(self) -> dict:
        if not Plugin.settings.get("api_key"):
            return {"ok": False, "error": "Inserisci la chiave API della trascrizione nel pannello."}
        try:
            await Plugin.recorder.start(Plugin._env())
        except (OSError, RuntimeError) as e:
            return {"ok": False, "error": str(e)}
        return {"ok": True}

    async def voice_stop(self) -> dict:
        """Stop recording, transcribe, and type the text into Claude's prompt."""
        try:
            audio = await Plugin.recorder.stop()
            s = Plugin.settings
            text = await asyncio.get_running_loop().run_in_executor(
                None,
                voice.transcribe,
                s.get("api_url"),
                s.get("api_key"),
                s.get("api_model"),
                s.get("language"),
                audio,
            )
        except RuntimeError as e:
            return {"ok": False, "error": str(e)}
        if text:
            # Bracketed paste keeps newlines in the transcript from sending early.
            Plugin.session.write("\x1b[200~" + text + "\x1b[201~")
            if Plugin.settings.get("auto_enter"):
                await asyncio.sleep(0.15)
                Plugin.session.write("\r")
        return {"ok": True, "text": text}

    async def voice_cancel(self) -> bool:
        await Plugin.recorder.cancel()
        return True
