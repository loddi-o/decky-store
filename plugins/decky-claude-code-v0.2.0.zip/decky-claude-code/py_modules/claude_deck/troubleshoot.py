"""Quick-start problems: each one prepares a folder Claude starts in, with the
facts it needs and the rules for touching a gaming device."""

import json
import os
import platform
import re
import shutil
import time
from typing import Any, Dict, List, Optional, Tuple

from . import steam

ISSUES: List[Dict[str, Any]] = [
    {
        "id": "game_wont_start",
        "title": "Un gioco non si avvia",
        "subtitle": "Schermo nero, si chiude subito, resta su «Avvio in corso»",
        "needs_game": True,
        "prompt": "Il gioco «{game}» non si avvia sul mio Steam Deck.",
    },
    {
        "id": "game_crash",
        "title": "Un gioco crasha o si blocca",
        "subtitle": "Si chiude durante il gioco, si congela, errori",
        "needs_game": True,
        "prompt": "Il gioco «{game}» crasha o si blocca mentre gioco.",
    },
    {
        "id": "game_performance",
        "title": "Un gioco è lento o scatta",
        "subtitle": "FPS bassi, stuttering, caricamenti lunghi",
        "needs_game": True,
        "prompt": "Il gioco «{game}» va lento o scatta.",
    },
    {
        "id": "game_controls",
        "title": "I controlli non funzionano in un gioco",
        "subtitle": "Tasti sbagliati, controller non visto, layout",
        "needs_game": True,
        "prompt": "In «{game}» i controlli non funzionano come dovrebbero.",
    },
    {
        "id": "audio",
        "title": "Audio o microfono",
        "subtitle": "Niente suono, cuffie Bluetooth, microfono muto",
        "needs_game": False,
        "prompt": "Ho un problema con l'audio o il microfono del mio Steam Deck.",
    },
    {
        "id": "network",
        "title": "Wi-Fi e rete",
        "subtitle": "Non si connette, lento, download bloccati",
        "needs_game": False,
        "prompt": "Ho un problema con il Wi-Fi o la rete del mio Steam Deck.",
    },
    {
        "id": "storage",
        "title": "Spazio su disco",
        "subtitle": "Memoria piena, cosa occupa spazio, scheda SD",
        "needs_game": False,
        "prompt": "Lo spazio su disco del mio Steam Deck sta finendo: aiutami a capire cosa occupa spazio e cosa posso liberare.",
    },
    {
        "id": "after_update",
        "title": "Problemi dopo un aggiornamento",
        "subtitle": "SteamOS, Decky o un plugin hanno smesso di funzionare",
        "needs_game": False,
        "prompt": "Dopo un aggiornamento qualcosa sul mio Steam Deck ha smesso di funzionare (SteamOS, Decky Loader o un plugin).",
    },
]

DIAGNOSE = (
    " Leggi CONTEXT.md in questa cartella, poi indaga sulle cause probabili leggendo log e configurazione"
    " del sistema. Spiegami cosa hai trovato in poche righe e proponimi le soluzioni in ordine di probabilità,"
    " come elenco numerato. Prima di applicare una modifica chiedimi conferma."
)

GUIDE = """# Assistente Steam Deck

Stai aiutando l'utente a risolvere un problema sul suo Steam Deck. Questa sessione è stata
aperta dal plugin Decky «Claude Code» in Modalità Gioco: l'utente usa il controller e la
tastiera a schermo, quindi scrivere è scomodo.

## Come rispondere
- Rispondi in italiano, in modo breve e chiaro, senza gergo.
- Quando l'utente deve scegliere, proponi opzioni numerate: può rispondere con un solo numero.
- Fai una cosa alla volta e spiega cosa stai per fare prima di farlo.
- Se l'utente deve agire in Steam (proprietà del gioco, compatibilità, impostazioni), dagli il
  percorso esatto nei menu, ad esempio: Libreria → gioco → ⚙ → Proprietà → Compatibilità.

## Regole di sicurezza
- La partizione di sistema di SteamOS è in sola lettura. Non usare `sudo`, `steamos-readonly
  disable`, `pacman` o `flatpak` di sistema senza chiedere esplicitamente all'utente, spiegando
  i rischi. Molti problemi si risolvono senza toccare il sistema.
- Prima di modificare un file, copialo in `backups/` dentro questa cartella.
- Non cancellare mai `compatdata` (prefix di Proton), salvataggi o cartelle di gioco senza un
  backup e una conferma esplicita: in compatdata possono esserci i salvataggi.
- Steam riscrive `localconfig.vdf`, `config.vdf` e `shortcuts.vdf` mentre è in esecuzione: non
  modificarli. Per opzioni di avvio, versione di Proton o compatibilità, dì all'utente cosa
  cambiare dall'interfaccia di Steam.
- Non chiudere né riavviare Steam (l'utente è in Modalità Gioco: perderebbe la sessione).

## Dove guardare
- Steam: `{steam_root}` (log in `logs/`: `console-linux.txt`, `compat_log.txt`,
  `content_log.txt`, `shader_log.txt`).
- Librerie di giochi: {libraries}
- Prefix di Proton: `<libreria>/steamapps/compatdata/<appid>/pfx`
- Log di Proton: se servono, chiedi all'utente di aggiungere `PROTON_LOG=1 %command%` alle opzioni
  di avvio e di riprovare il gioco; il log comparirà in `~/steam-<appid>.log`.
- Log di sistema: `journalctl --user -b` e `journalctl -b` (potrebbe servire il gruppo giusto).
- Decky Loader: `~/homebrew/` (plugin in `~/homebrew/plugins`, log in `~/homebrew/logs`).
- Per provare di nuovo un gioco, chiedi all'utente di avviarlo da Steam e di tornare qui:
  questa sessione resta aperta.
"""


def workspace_root(home: str) -> str:
    return os.path.join(home, ".local", "share", "claude-deck", "assist")


def _slug(text: str) -> str:
    return re.sub(r"[^a-z0-9]+", "-", text.lower()).strip("-")[:40] or "gioco"


def _system_facts(home: str) -> Dict[str, str]:
    facts: Dict[str, str] = {}
    try:
        with open("/etc/os-release", "r", encoding="utf-8") as f:
            for line in f:
                key, _, value = line.strip().partition("=")
                if key in ("PRETTY_NAME", "VERSION_ID", "BUILD_ID", "VARIANT_ID"):
                    facts[key] = value.strip('"')
    except OSError:
        pass
    facts["kernel"] = platform.release()
    try:
        with open("/sys/devices/virtual/dmi/id/product_name", "r", encoding="utf-8") as f:
            facts["model"] = f.read().strip()  # Jupiter = LCD, Galileo = OLED
    except OSError:
        pass
    usage = shutil.disk_usage(home)
    facts["home_free"] = f"{usage.free / 1e9:.1f} GB liberi su {usage.total / 1e9:.1f} GB"
    return facts


def _describe_game(details: Dict[str, Any]) -> List[str]:
    labels = [
        ("name", "Nome"),
        ("appid", "AppID"),
        ("kind", "Tipo (steam = gioco Steam, shortcut = gioco non Steam)"),
        ("install_dir", "Cartella di installazione"),
        ("exe", "Eseguibile"),
        ("start_dir", "Cartella di avvio"),
        ("build_id", "Build"),
        ("compat_tool", "Strumento di compatibilità forzato (vuoto = predefinito di Steam)"),
        ("launch_options", "Opzioni di avvio"),
        ("compatdata", "Prefix Proton (compatdata)"),
        ("shadercache", "Cache shader"),
        ("proton_log", "Log Proton esistente"),
        ("manifest", "Manifest"),
        ("shortcuts_file", "File dei giochi non Steam"),
    ]
    lines = []
    for key, label in labels:
        value = details.get(key)
        if value:
            lines.append(f"- {label}: `{value}`")
    if details.get("size_on_disk"):
        lines.append(f"- Dimensione: {details['size_on_disk'] / 1e9:.1f} GB")
    if details.get("last_played"):
        lines.append("- Ultimo avvio: " + time.strftime("%Y-%m-%d %H:%M", time.localtime(details["last_played"])))
    return lines


def prepare(home: str, issue_id: str, appid: str = "") -> Tuple[str, str, List[str]]:
    """Create the session folder. Returns (cwd, first prompt, extra readable dirs)."""
    issue = next((i for i in ISSUES if i["id"] == issue_id), None)
    if issue is None:
        raise ValueError(f"Problema sconosciuto: {issue_id}")

    root = steam.steam_root(home)
    libraries = steam.library_paths(root)
    details: Optional[Dict[str, Any]] = steam.game_details(home, appid) if appid else None
    game_name = (details or {}).get("name") or appid

    folder = issue_id if not details else f"{issue_id}-{_slug(game_name)}"
    cwd = os.path.join(workspace_root(home), folder)
    os.makedirs(os.path.join(cwd, "backups"), exist_ok=True)

    with open(os.path.join(cwd, "CLAUDE.md"), "w", encoding="utf-8") as f:
        f.write(
            GUIDE.format(
                steam_root=root,
                libraries=", ".join(f"`{p}`" for p in libraries),
            )
        )

    lines = [f"# {issue['title']}", "", f"Aperto il {time.strftime('%Y-%m-%d %H:%M')}.", "", "## Sistema"]
    lines += [f"- {k}: {v}" for k, v in _system_facts(home).items()]
    if details:
        lines += ["", "## Gioco"] + _describe_game(details)
    lines += ["", "## Dati grezzi", "```json", json.dumps(details or {}, indent=2, ensure_ascii=False), "```", ""]
    with open(os.path.join(cwd, "CONTEXT.md"), "w", encoding="utf-8") as f:
        f.write("\n".join(lines))

    prompt = issue["prompt"].format(game=game_name) + DIAGNOSE
    readable = [root] + libraries
    for key in ("install_dir", "start_dir"):
        path = (details or {}).get(key)
        if path and os.path.isdir(path):
            readable.append(path)
    decky_home = os.path.join(home, "homebrew")
    if issue_id == "after_update" and os.path.isdir(decky_home):
        readable.append(decky_home)
    # Keep order, drop duplicates.
    seen, dirs = set(), []
    for d in readable:
        real = os.path.realpath(d)
        if real not in seen and os.path.isdir(real):
            seen.add(real)
            dirs.append(real)
    return cwd, prompt, dirs


def trust_folder(home: str, path: str) -> None:
    """Mark a folder the plugin created as trusted, so Claude skips the
    "do you trust this folder?" question (its default answer exits)."""
    config = os.path.join(home, ".claude.json")
    try:
        with open(config, "r", encoding="utf-8") as f:
            data = json.load(f)
    except FileNotFoundError:
        data = {}
    except (OSError, ValueError):
        return  # Never rewrite a file we could not read.
    if not isinstance(data, dict):
        return
    projects = data.setdefault("projects", {})
    project = projects.setdefault(path, {})
    if project.get("hasTrustDialogAccepted") is True:
        return
    project["hasTrustDialogAccepted"] = True
    tmp = config + ".claude-deck.tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)
    os.replace(tmp, config)


def public_issues() -> List[Dict[str, Any]]:
    return [{k: v for k, v in i.items() if k != "prompt"} for i in ISSUES]
