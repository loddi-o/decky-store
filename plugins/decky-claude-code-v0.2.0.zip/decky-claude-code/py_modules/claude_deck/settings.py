import json
import os
from typing import Any, Dict

DEFAULTS: Dict[str, Any] = {
    # Empty means "find it automatically" (see session.find_claude).
    "claude_path": "",
    "cwd": "",
    "extra_args": "",
    "recent_dirs": [],
    "font_size": 15,
    # Make room for the on-screen keyboard while it is open.
    "shrink_on_keyboard": True,
    # "claude": Claude Code's own /voice dictation (needs a claude.ai login).
    # "api": record with PipeWire and send to a Whisper-compatible endpoint.
    # "off": the voice button does nothing.
    "voice_engine": "claude",
    "api_url": "https://api.groq.com/openai/v1/audio/transcriptions",
    "api_key": "",
    "api_model": "whisper-large-v3-turbo",
    "language": "it",
    "auto_enter": False,
}

# Settings the frontend may change; everything else is internal.
EDITABLE = set(DEFAULTS) - {"recent_dirs"}


class Settings:
    def __init__(self, directory: str):
        self.path = os.path.join(directory, "settings.json")
        self.data: Dict[str, Any] = dict(DEFAULTS)
        try:
            with open(self.path, "r", encoding="utf-8") as f:
                stored = json.load(f)
            if isinstance(stored, dict):
                self.data.update({k: v for k, v in stored.items() if k in DEFAULTS})
        except (OSError, ValueError):
            pass

    def get(self, key: str) -> Any:
        return self.data.get(key, DEFAULTS.get(key))

    def update(self, values: Dict[str, Any]) -> None:
        for key, value in values.items():
            if key in EDITABLE:
                self.data[key] = value
        self.save()

    def remember_dir(self, path: str) -> None:
        dirs = [d for d in self.data.get("recent_dirs", []) if d != path]
        self.data["recent_dirs"] = [path] + dirs[:5]
        self.save()

    def save(self) -> None:
        os.makedirs(os.path.dirname(self.path), exist_ok=True)
        tmp = self.path + ".tmp"
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(self.data, f, indent=2)
        os.replace(tmp, self.path)

    def public(self) -> Dict[str, Any]:
        """Settings as shown to the frontend; the API key is never sent back."""
        data = dict(self.data)
        data["api_key_set"] = bool(data.pop("api_key", ""))
        return data
