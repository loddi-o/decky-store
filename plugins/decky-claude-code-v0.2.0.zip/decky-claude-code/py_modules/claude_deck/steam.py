"""Read what Steam knows about installed games, straight from its files."""

import glob
import os
import re
import struct
from typing import Any, Dict, List, Optional

# Steam entries that are not games.
NOT_GAMES = re.compile(
    r"^(Proton|Steam Linux Runtime|Steamworks Common|SteamVR|Steam Audio)", re.IGNORECASE
)


def steam_root(home: str) -> str:
    for path in (".local/share/Steam", ".steam/steam", ".steam/root"):
        full = os.path.join(home, path)
        if os.path.isdir(os.path.join(full, "steamapps")):
            return os.path.realpath(full)
    return os.path.join(home, ".local/share/Steam")


# ---- text VDF (KeyValues) ---------------------------------------------------

_TOKEN = re.compile(r'"((?:\\.|[^"\\])*)"|([{}])|(//[^\n]*)')


def parse_vdf(text: str) -> Dict[str, Any]:
    root: Dict[str, Any] = {}
    stack = [root]
    key: Optional[str] = None
    for m in _TOKEN.finditer(text):
        string, brace, comment = m.groups()
        if comment is not None:
            continue
        if brace == "{":
            child: Dict[str, Any] = {}
            stack[-1][key or ""] = child
            stack.append(child)
            key = None
        elif brace == "}":
            if len(stack) > 1:
                stack.pop()
            key = None
        elif key is None:
            key = string.replace('\\"', '"').replace("\\\\", "\\")
        else:
            stack[-1][key] = string.replace('\\"', '"').replace("\\\\", "\\")
            key = None
    return root


def read_vdf(path: str) -> Dict[str, Any]:
    try:
        with open(path, "r", encoding="utf-8", errors="replace") as f:
            return parse_vdf(f.read())
    except OSError:
        return {}


def lower_keys(d: Any) -> Any:
    """Steam is inconsistent about key case, so look things up in lower case."""
    if isinstance(d, dict):
        return {k.lower(): lower_keys(v) for k, v in d.items()}
    return d


def dig(d: Any, *keys: str) -> Any:
    for key in keys:
        if not isinstance(d, dict):
            return None
        d = d.get(key.lower())
    return d


# ---- binary VDF (shortcuts.vdf) ---------------------------------------------


def parse_binary_vdf(data: bytes) -> Dict[str, Any]:
    pos = 0

    def cstring() -> str:
        nonlocal pos
        end = data.index(b"\x00", pos)
        s = data[pos:end].decode("utf-8", errors="replace")
        pos = end + 1
        return s

    def mapping() -> Dict[str, Any]:
        nonlocal pos
        out: Dict[str, Any] = {}
        while pos < len(data):
            kind = data[pos]
            pos += 1
            if kind == 0x08:
                return out
            name = cstring()
            if kind == 0x00:
                out[name] = mapping()
            elif kind == 0x01:
                out[name] = cstring()
            elif kind == 0x02:
                out[name] = struct.unpack_from("<I", data, pos)[0]
                pos += 4
            elif kind == 0x07:
                out[name] = struct.unpack_from("<Q", data, pos)[0]
                pos += 8
            else:
                raise ValueError(f"unknown binary VDF type {kind}")
        return out

    return mapping()


# ---- Steam data -------------------------------------------------------------


def library_paths(root: str) -> List[str]:
    paths = [root]
    folders = lower_keys(read_vdf(os.path.join(root, "steamapps", "libraryfolders.vdf")))
    for entry in (dig(folders, "libraryfolders") or {}).values():
        path = entry.get("path") if isinstance(entry, dict) else None
        if path and os.path.isdir(path) and os.path.realpath(path) not in map(os.path.realpath, paths):
            paths.append(path)
    return paths


def user_config_dir(root: str) -> Optional[str]:
    """The config folder of the Steam user who logged in most recently."""
    configs = glob.glob(os.path.join(root, "userdata", "*", "config", "localconfig.vdf"))
    if not configs:
        return None
    return os.path.dirname(max(configs, key=os.path.getmtime))


def _local_apps(root: str) -> Dict[str, Any]:
    config = user_config_dir(root)
    if not config:
        return {}
    local = lower_keys(read_vdf(os.path.join(config, "localconfig.vdf")))
    return dig(local, "UserLocalConfigStore", "Software", "Valve", "Steam", "apps") or {}


def _compat_tools(root: str) -> Dict[str, str]:
    cfg = lower_keys(read_vdf(os.path.join(root, "config", "config.vdf")))
    mapping = dig(cfg, "InstallConfigStore", "Software", "Valve", "Steam", "CompatToolMapping") or {}
    return {appid: v.get("name", "") for appid, v in mapping.items() if isinstance(v, dict)}


def _int(value: Any) -> int:
    try:
        return int(value)
    except (TypeError, ValueError):
        return 0


def list_games(home: str) -> List[Dict[str, Any]]:
    root = steam_root(home)
    local = _local_apps(root)
    compat = _compat_tools(root)
    games: Dict[str, Dict[str, Any]] = {}

    for library in library_paths(root):
        for manifest in glob.glob(os.path.join(library, "steamapps", "appmanifest_*.acf")):
            app = lower_keys(read_vdf(manifest)).get("appstate", {})
            appid, name = app.get("appid"), app.get("name", "")
            if not appid or not name or NOT_GAMES.match(name):
                continue
            games[appid] = {
                "appid": appid,
                "name": name,
                "kind": "steam",
                "last_played": _int(dig(local, appid, "LastPlayed")),
                "compat_tool": compat.get(appid, ""),
            }

    config = user_config_dir(root)
    if config:
        try:
            with open(os.path.join(config, "shortcuts.vdf"), "rb") as f:
                shortcuts = lower_keys(parse_binary_vdf(f.read())).get("shortcuts", {})
        except (OSError, ValueError, IndexError, struct.error):
            shortcuts = {}
        for entry in shortcuts.values():
            if not isinstance(entry, dict) or not entry.get("appname"):
                continue
            appid = str(entry.get("appid", 0) & 0xFFFFFFFF)
            games[appid] = {
                "appid": appid,
                "name": entry["appname"],
                "kind": "shortcut",
                "last_played": _int(entry.get("lastplaytime")),
                "compat_tool": compat.get(appid, ""),
            }

    return sorted(games.values(), key=lambda g: (-g["last_played"], g["name"].lower()))


def game_details(home: str, appid: str) -> Dict[str, Any]:
    """Everything useful for troubleshooting one game: paths, Proton, launch options."""
    root = steam_root(home)
    libraries = library_paths(root)
    info: Dict[str, Any] = {"appid": appid, "steam_root": root, "libraries": libraries}

    for library in libraries:
        manifest = os.path.join(library, "steamapps", f"appmanifest_{appid}.acf")
        if os.path.exists(manifest):
            app = lower_keys(read_vdf(manifest)).get("appstate", {})
            info.update(
                kind="steam",
                name=app.get("name", ""),
                manifest=manifest,
                install_dir=os.path.join(library, "steamapps", "common", app.get("installdir", "")),
                build_id=app.get("buildid", ""),
                size_on_disk=_int(app.get("sizeondisk")),
                state_flags=app.get("stateflags", ""),
            )
            break

    config = user_config_dir(root)
    if "kind" not in info and config:
        try:
            with open(os.path.join(config, "shortcuts.vdf"), "rb") as f:
                shortcuts = lower_keys(parse_binary_vdf(f.read())).get("shortcuts", {})
        except (OSError, ValueError, IndexError, struct.error):
            shortcuts = {}
        for entry in shortcuts.values():
            if isinstance(entry, dict) and str(entry.get("appid", 0) & 0xFFFFFFFF) == appid:
                info.update(
                    kind="shortcut",
                    name=entry.get("appname", ""),
                    exe=entry.get("exe", "").strip('"'),
                    start_dir=entry.get("startdir", "").strip('"'),
                    launch_options=entry.get("launchoptions", ""),
                    shortcuts_file=os.path.join(config, "shortcuts.vdf"),
                )
                break

    local = dig(_local_apps(root), appid) or {}
    if info.get("kind") == "steam":
        info["launch_options"] = local.get("launchoptions", "")
    info["last_played"] = _int(local.get("lastplayed")) or None
    info["compat_tool"] = _compat_tools(root).get(appid, "")
    info["localconfig"] = os.path.join(config, "localconfig.vdf") if config else None

    for library in libraries:
        for key, sub in (("compatdata", "compatdata"), ("shadercache", "shadercache")):
            path = os.path.join(library, "steamapps", sub, appid)
            if os.path.isdir(path) and key not in info:
                info[key] = path
    info["steam_logs"] = os.path.join(root, "logs")
    proton_log = os.path.join(home, f"steam-{appid}.log")
    if os.path.exists(proton_log):
        info["proton_log"] = proton_log
    return info
