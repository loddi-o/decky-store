import asyncio
import codecs
import fcntl
import os
import pty
import select
import shlex
import shutil
import signal
import struct
import subprocess
import termios
from typing import Awaitable, Callable, List, Optional

# Where the official installers put the `claude` binary, relative to $HOME.
CANDIDATE_DIRS = [
    ".local/bin",
    ".claude/local",
    ".npm-global/bin",
    ".bun/bin",
    ".volta/bin",
    ".nix-profile/bin",
    "bin",
]

# How much recent output is kept so a reloaded UI can redraw the screen.
SCROLLBACK_CHARS = 400_000
# Output is batched for this long before it is sent to the frontend.
FLUSH_DELAY = 0.012


def user_path(home: str) -> str:
    dirs = [os.path.join(home, d) for d in CANDIDATE_DIRS]
    dirs += ["/usr/local/bin", "/usr/bin", "/bin"]
    return os.pathsep.join(dirs)


def user_env(home: str, user: str) -> dict:
    """Environment for programs started as the Deck user.

    Decky runs plugins from a bundled Python whose LD_LIBRARY_PATH would break
    native modules (Claude Code's audio recorder among them), so it is dropped.
    """
    env = {k: v for k, v in os.environ.items() if not k.startswith(("LD_", "PYTHON", "_MEI"))}
    uid = os.getuid()
    runtime = f"/run/user/{uid}"
    env.update(
        {
            "HOME": home,
            "USER": user,
            "LOGNAME": user,
            "PATH": user_path(home),
            "TERM": "xterm-256color",
            "COLORTERM": "truecolor",
            "XDG_RUNTIME_DIR": runtime,
            "DBUS_SESSION_BUS_ADDRESS": f"unix:path={runtime}/bus",
        }
    )
    env.setdefault("LANG", "C.UTF-8")
    env.setdefault("SHELL", "/bin/bash")
    return env


def find_claude(home: str, override: str = "") -> Optional[str]:
    if override:
        path = os.path.expanduser(override)
        return path if os.access(path, os.X_OK) else None
    return shutil.which("claude", path=user_path(home))


def claude_version(binary: str, env: dict) -> Optional[str]:
    try:
        out = subprocess.run(
            [binary, "--version"], env=env, capture_output=True, text=True, timeout=15
        )
        return (out.stdout or out.stderr).strip().splitlines()[0] if out.returncode == 0 else None
    except (OSError, subprocess.SubprocessError, IndexError):
        return None


class ClaudeSession:
    """One `claude` process running in a pseudo-terminal."""

    def __init__(
        self,
        on_output: Callable[[str], Awaitable[None]],
        on_exit: Callable[[int], Awaitable[None]],
        logger,
    ):
        self.on_output = on_output
        self.on_exit = on_exit
        self.logger = logger
        self.process: Optional[asyncio.subprocess.Process] = None
        self.master_fd: Optional[int] = None
        self.rows = 30
        self.cols = 100
        self.cwd = ""
        self.mode = ""
        self.scrollback = ""
        self._pending: List[str] = []
        self._flush_handle: Optional[asyncio.TimerHandle] = None
        self._decoder = codecs.getincrementaldecoder("utf-8")(errors="replace")
        self._loop: Optional[asyncio.AbstractEventLoop] = None

    @property
    def running(self) -> bool:
        return self.process is not None and self.process.returncode is None

    async def start(self, binary: str, args: List[str], cwd: str, env: dict, mode: str) -> None:
        await self.stop()
        self._loop = asyncio.get_running_loop()
        self.cwd = cwd
        self.mode = mode
        self.scrollback = ""
        self._decoder.reset()

        master, slave = pty.openpty()
        self._set_size(master, self.rows, self.cols)
        env = dict(env, LINES=str(self.rows), COLUMNS=str(self.cols))

        def preexec():
            os.setsid()
            fcntl.ioctl(0, termios.TIOCSCTTY, 0)

        self.logger.info("Starting %s in %s", shlex.join([binary] + args), cwd)
        try:
            self.process = await asyncio.create_subprocess_exec(
                binary,
                *args,
                stdin=slave,
                stdout=slave,
                stderr=slave,
                cwd=cwd,
                env=env,
                preexec_fn=preexec,
            )
        finally:
            os.close(slave)

        self.master_fd = master
        os.set_blocking(master, False)
        self._loop.add_reader(master, self._on_readable)
        asyncio.ensure_future(self._wait())

    def _on_readable(self) -> None:
        try:
            data = os.read(self.master_fd, 65536)
        except (BlockingIOError, InterruptedError):
            return
        except OSError:
            # EIO: the child closed the terminal.
            data = b""
        if not data:
            self._close_fd()
            return
        text = self._decoder.decode(data)
        if text:
            self._pending.append(text)
            if self._flush_handle is None:
                self._flush_handle = self._loop.call_later(FLUSH_DELAY, self._flush)

    def _flush(self) -> None:
        self._flush_handle = None
        if not self._pending:
            return
        chunk = "".join(self._pending)
        self._pending.clear()
        self.scrollback = (self.scrollback + chunk)[-SCROLLBACK_CHARS:]
        asyncio.ensure_future(self.on_output(chunk))

    async def _wait(self) -> None:
        process = self.process
        code = await process.wait()
        # Let the last output through before announcing the exit.
        await asyncio.sleep(0.05)
        self._drain()
        self._flush()
        if process is self.process:
            self._close_fd()
            self.logger.info("claude exited with %s", code)
            await self.on_exit(code)

    def _drain(self) -> None:
        """Read whatever the child wrote before it exited."""
        for _ in range(256):
            fd = self.master_fd
            if fd is None or not select.select([fd], [], [], 0)[0]:
                return
            self._on_readable()

    def _close_fd(self) -> None:
        if self.master_fd is None:
            return
        try:
            self._loop.remove_reader(self.master_fd)
        except Exception:
            pass
        try:
            os.close(self.master_fd)
        except OSError:
            pass
        self.master_fd = None

    def write(self, data: str) -> None:
        if self.master_fd is None or not self.running:
            return
        payload = data.encode("utf-8")
        while payload:
            try:
                written = os.write(self.master_fd, payload)
            except BlockingIOError:
                # The child is not reading fast enough; pasting long text can
                # fill the PTY buffer, so wait for it to drain.
                select.select([], [self.master_fd], [], 1.0)
                continue
            payload = payload[written:]

    def resize(self, rows: int, cols: int) -> None:
        rows, cols = max(int(rows), 5), max(int(cols), 20)
        self.rows, self.cols = rows, cols
        if self.master_fd is not None:
            self._set_size(self.master_fd, rows, cols)
            if self.running:
                try:
                    os.killpg(self.process.pid, signal.SIGWINCH)
                except OSError:
                    pass

    @staticmethod
    def _set_size(fd: int, rows: int, cols: int) -> None:
        fcntl.ioctl(fd, termios.TIOCSWINSZ, struct.pack("HHHH", rows, cols, 0, 0))

    async def stop(self) -> None:
        process = self.process
        if process is None:
            return
        self.process = None
        if process.returncode is None:
            try:
                os.killpg(process.pid, signal.SIGHUP)
            except OSError:
                pass
            try:
                await asyncio.wait_for(process.wait(), 3)
            except asyncio.TimeoutError:
                try:
                    os.killpg(process.pid, signal.SIGKILL)
                except OSError:
                    pass
        self._close_fd()
