import asyncio
import json
import os
import shutil
import signal
import tempfile
import urllib.error
import urllib.request
import uuid
from typing import List, Optional

# Claude Code's dictation languages, as names its `language` setting accepts.
CLAUDE_LANGUAGES = {
    "it": "italian",
    "en": "english",
    "es": "spanish",
    "fr": "french",
    "de": "german",
    "pt": "portuguese",
}


def recorder_command(path: str, out_file: str) -> Optional[List[str]]:
    """A command that records 16 kHz mono WAV from the default microphone."""
    pw = shutil.which("pw-record", path=path)
    if pw:
        return [pw, "--rate", "16000", "--channels", "1", "--format", "s16", out_file]
    parec = shutil.which("parecord", path=path)
    if parec:
        return [parec, "--rate=16000", "--channels=1", "--format=s16le", "--file-format=wav", out_file]
    arecord = shutil.which("arecord", path=path)
    if arecord:
        return [arecord, "-q", "-f", "S16_LE", "-r", "16000", "-c", "1", "-t", "wav", out_file]
    return None


class Recorder:
    def __init__(self, logger):
        self.logger = logger
        self.process: Optional[asyncio.subprocess.Process] = None
        self.file = ""

    @property
    def recording(self) -> bool:
        return self.process is not None and self.process.returncode is None

    async def start(self, env: dict) -> None:
        if self.recording:
            return
        self.file = os.path.join(tempfile.gettempdir(), f"claude-deck-{uuid.uuid4().hex}.wav")
        cmd = recorder_command(env["PATH"], self.file)
        if cmd is None:
            raise RuntimeError("Nessun programma di registrazione trovato (pw-record, parecord o arecord).")
        self.process = await asyncio.create_subprocess_exec(
            *cmd, env=env, stdout=asyncio.subprocess.DEVNULL, stderr=asyncio.subprocess.PIPE
        )

    async def stop(self) -> bytes:
        """Stop recording and return the WAV data."""
        process, self.process = self.process, None
        if process is None:
            raise RuntimeError("Nessuna registrazione in corso.")
        if process.returncode is None:
            # SIGINT lets every recorder finish the WAV header properly.
            process.send_signal(signal.SIGINT)
            try:
                await asyncio.wait_for(process.wait(), 3)
            except asyncio.TimeoutError:
                process.kill()
                await process.wait()
        try:
            with open(self.file, "rb") as f:
                data = f.read()
        except OSError:
            err = (await process.stderr.read()).decode(errors="replace").strip()
            raise RuntimeError(f"Registrazione non riuscita. {err}".strip())
        finally:
            try:
                os.remove(self.file)
            except OSError:
                pass
        if len(data) < 16000:  # less than half a second of audio
            raise RuntimeError("Registrazione troppo breve.")
        return data

    async def cancel(self) -> None:
        if self.recording:
            try:
                await self.stop()
            except RuntimeError:
                pass


def _multipart(fields: dict, file_bytes: bytes):
    boundary = uuid.uuid4().hex
    parts = []
    for name, value in fields.items():
        parts.append(
            f'--{boundary}\r\nContent-Disposition: form-data; name="{name}"\r\n\r\n{value}\r\n'.encode()
        )
    parts.append(
        (
            f'--{boundary}\r\nContent-Disposition: form-data; name="file"; filename="audio.wav"\r\n'
            "Content-Type: audio/wav\r\n\r\n"
        ).encode()
        + file_bytes
        + b"\r\n"
    )
    parts.append(f"--{boundary}--\r\n".encode())
    return b"".join(parts), f"multipart/form-data; boundary={boundary}"


def transcribe(url: str, key: str, model: str, language: str, audio: bytes) -> str:
    """Send audio to an OpenAI-compatible /audio/transcriptions endpoint."""
    fields = {"model": model, "response_format": "json"}
    if language:
        fields["language"] = language
    body, content_type = _multipart(fields, audio)
    request = urllib.request.Request(
        url,
        data=body,
        method="POST",
        headers={"Authorization": f"Bearer {key}", "Content-Type": content_type},
    )
    try:
        with urllib.request.urlopen(request, timeout=60) as response:
            payload = json.loads(response.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        detail = e.read().decode("utf-8", errors="replace")[:200]
        raise RuntimeError(f"Il servizio di trascrizione ha risposto {e.code}: {detail}")
    except urllib.error.URLError as e:
        raise RuntimeError(f"Servizio di trascrizione non raggiungibile: {e.reason}")
    return str(payload.get("text", "")).strip()


def claude_settings_path(home: str) -> str:
    return os.path.join(home, ".claude", "settings.json")


def claude_voice_status(home: str) -> dict:
    try:
        with open(claude_settings_path(home), "r", encoding="utf-8") as f:
            data = json.load(f)
    except (OSError, ValueError):
        data = {}
    voice = data.get("voice") if isinstance(data.get("voice"), dict) else {}
    return {
        "enabled": bool(voice.get("enabled")),
        "mode": voice.get("mode", "hold"),
        "language": data.get("language", ""),
    }


def enable_claude_voice(home: str, language: str) -> dict:
    """Turn on Claude Code's dictation in tap mode, keeping every other setting."""
    path = claude_settings_path(home)
    try:
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
        if not isinstance(data, dict):
            raise ValueError("settings.json is not an object")
    except FileNotFoundError:
        data = {}
    voice = data.get("voice") if isinstance(data.get("voice"), dict) else {}
    voice.update({"enabled": True, "mode": "tap"})
    data["voice"] = voice
    # Only fill the language in when it is unset: it also sets the language
    # Claude answers in, which the user may have chosen on purpose.
    if not data.get("language") and language in CLAUDE_LANGUAGES:
        data["language"] = CLAUDE_LANGUAGES[language]
    os.makedirs(os.path.dirname(path), exist_ok=True)
    tmp = path + ".claude-deck.tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)
    os.replace(tmp, path)
    return claude_voice_status(home)
