# Claude Code per Steam Deck (plugin Decky)

Usa [Claude Code](https://code.claude.com) in Modalità Gioco, senza passare al Desktop. Il plugin apre dal menu di accesso rapido (il tasto `…`) una sessione di `claude` a schermo intero, esattamente come nel terminale, con i comandi mappati sul controller e la dettatura vocale.

## Cosa serve

- [Decky Loader](https://decky.xyz) installato.
- Claude Code installato sul Deck e già collegato al tuo account. Dalla modalità Desktop, in Konsole:
  ```bash
  curl -fsSL https://claude.ai/install.sh | bash
  claude   # la prima volta, per fare l'accesso
  ```
  Il plugin trova `claude` in `~/.local/bin`, `~/.claude/local`, `~/.npm-global/bin` e negli altri percorsi comuni.

## Installazione

1. Scarica `decky-claude-code-vX.Y.Z.zip` (dalle release, o crealo con `./scripts/package.sh`).
2. In Decky: Impostazioni → Generale → attiva **Modalità sviluppatore**.
3. Impostazioni → Sviluppatore → **Installa plugin da ZIP** e scegli il file.

## Uso

Apri il menu rapido, scegli **Claude Code** e premi **Apri Claude Code**. Si apre la schermata delle opzioni rapide:

- **Chiedi a Claude**, **Continua** e **Scegli conversazione** per una sessione normale, nella cartella scelta nel pannello.
- **Risoluzione problemi**: un gioco non si avvia, crasha, è lento o ha i controlli sbagliati; audio e microfono; Wi-Fi; spazio su disco; problemi dopo un aggiornamento. Per i problemi di un gioco scegli il gioco dall'elenco (Steam, non Steam e scheda SD, ordinati per ultimo avvio).

Con la risoluzione problemi Claude parte già informato. Il plugin crea una cartella in `~/.local/share/claude-deck/assist/` con un `CONTEXT.md` (sistema, percorsi del gioco, Proton, opzioni di avvio, prefix) e un `CLAUDE.md` con le regole. Claude non usa sudo, fa un backup prima di modificare un file, non cancella prefix o salvataggi senza conferma, non tocca i file di Steam mentre è in esecuzione e chiede sempre prima di applicare una soluzione. Può leggere le cartelle di Steam e del gioco senza chiedere il permesso ogni volta.

La sessione resta attiva quando esci dalla schermata o avvii un gioco: rientri con **Apri Claude Code**.

### Comandi del controller

| Tasto | Azione |
| --- | --- |
| A | Invio (a sessione chiusa: torna alle opzioni rapide) |
| B | Esc (interrompe Claude, chiude i menu) |
| X / □ | Apre la tastiera a schermo |
| Y / △ | Dettatura: premi per parlare, premi di nuovo per inviare |
| Croce direzionale | Frecce (menu e cronologia) |
| L1 / R1 | Shift+Tab (cambia modalità) / Tab |
| L2 / R2 | Scorri su / giù |
| R3 | Backspace |
| L3 | Ctrl+C |
| ≡ (Menu) | Comandi rapidi: /clear, /compact, /model, /resume, opzioni rapide… |
| ⧉ (Vista) | Torna indietro (la sessione resta attiva) |

In basso c'è anche una barra di tasti per il touchscreen. La tastiera si apre solo quando la chiedi (X o il tasto ⌨), così non salta fuori da sola. Anche **Steam + X** funziona sempre: il terminale si restringe da solo per lasciarle spazio.

### Dettatura vocale

Nel pannello, sotto **Dettatura**, scegli il motore:

- **Claude Code (/voice)**, quello predefinito. Usa la dettatura integrata di Claude Code in modalità tap. Il plugin la attiva in `~/.claude/settings.json` all'avvio di ogni sessione e, se non hai già scelto una lingua, imposta quella del pannello. Richiede l'accesso con un account claude.ai (Pro o Max). L'audio viene trascritto dai server di Anthropic.
- **Whisper via API**. Registra dal microfono con PipeWire e invia l'audio a un servizio compatibile con OpenAI. Il predefinito è [Groq](https://console.groq.com), che ha un piano gratuito. Serve una chiave API. Il testo viene scritto nel prompt e, se attivi **Invia subito**, anche inviato.
- **Disattivata**.

## Sviluppo

```bash
pnpm install
pnpm build              # frontend in dist/
./scripts/package.sh    # zip installabile in out/
```

- `main.py` e `py_modules/claude_deck/` contengono il backend: avviano `claude` in uno pseudo-terminale come utente `deck` e gestiscono la registrazione e le impostazioni.
- `src/` contiene il frontend: il pannello del menu rapido (`Panel.tsx`), il terminale a schermo intero con [xterm.js](https://xtermjs.org) (`TerminalPage.tsx`, `controller.ts`) e il menu dei comandi (`CommandModal.tsx`).

Licenza BSD-3-Clause.
